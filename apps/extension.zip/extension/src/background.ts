// ── Configuration ──

import './posting-config.js';

import { API_BASE_URL, BUILD_ENV } from './env.js';

console.info(`[PostFlow] ${BUILD_ENV === 'production' ? 'PROD' : 'DEV'} environment | API: ${API_BASE_URL}`);

const HEARTBEAT_ALARM = 'postflow-heartbeat';
const HEARTBEAT_INTERVAL_MINUTES = 1;
const REGISTER_RETRY_ALARM = 'postflow-register-retry';
const REGISTER_RETRY_DELAY_MINUTES = 1;
const PENDING_POST_SYNC_ALARM = 'postflow-pending-post-sync';
const PENDING_POST_SYNC_INTERVAL_MINUTES = 10;
const ENGAGEMENT_SYNC_ALARM = 'postflow-engagement-sync';
const ENGAGEMENT_SYNC_INTERVAL_MINUTES = 30;
const EXTENSION_INSTANCE_ID_KEY = 'extensionInstanceId';
const EXTENSION_NAME_KEY = 'extensionName';
const TAB_ACTION_RETRY_COUNT = 6;
const TAB_ACTION_RETRY_DELAY_MS = 500;
const POSTING_TIMING = (globalThis as { PostFlowPostingTiming?: PostFlowPostingTimingConfig }).PostFlowPostingTiming!;

// ── Helpers ──

let extensionInstanceIdPromise: Promise<string> | null = null;

// Writes sanitized phone-sync diagnostics to the service worker DevTools console.
function logPhoneSync(
  level: 'info' | 'warn' | 'error',
  message: string,
  details?: Record<string, string | number>,
) {
  const prefix = `[PostFlow][Phone Collector] ${message}`;
  if (level === 'error') console.error(prefix, details ?? '');
  else if (level === 'warn') console.warn(prefix, details ?? '');
  else console.info(prefix, details ?? '');
}

interface ApiFetchFailure {
  apiFetchError: true;
  status: number;
}

// Identifies structured API failures returned only to callers that request details.
function isApiFetchFailure(value: unknown): value is ApiFetchFailure {
  return typeof value === 'object' && value !== null &&
    'apiFetchError' in value && value.apiFetchError === true &&
    'status' in value && typeof value.status === 'number';
}

// Checks that the backend returned every non-negative count needed by the popup.
function isPhoneSyncResult(value: unknown): value is PhoneSyncResult {
  if (typeof value !== 'object' || value === null) return false;
  const result = value as Record<string, unknown>;
  return ['submitted', 'valid', 'duplicates', 'invalid', 'added', 'alreadyExisted']
    .every((key) => Number.isInteger(result[key]) && Number(result[key]) >= 0);
}

// Converts HTTP/network status codes into safe, actionable sync errors for the popup.
function phoneSyncErrorForStatus(status: number): PhoneSyncResponse {
  if (status === 401) {
    return { ok: false, code: 'AUTH_REQUIRED', httpStatus: status, error: 'Your PostFlow session has expired. Sign in and try again.' };
  }
  if (status === 403) {
    return { ok: false, code: 'FORBIDDEN', httpStatus: status, error: 'Your account is not allowed to sync phone numbers.' };
  }
  if (status === 0) {
    return { ok: false, code: 'NETWORK_ERROR', httpStatus: status, error: 'Could not reach PostFlow. Check your connection and try again.' };
  }
  if (status >= 500) {
    return { ok: false, code: 'SERVER_ERROR', httpStatus: status, error: 'PostFlow is temporarily unavailable. Your selection is saved for retry.' };
  }
  return { ok: false, code: 'API_REJECTED', httpStatus: status, error: 'PostFlow rejected the sync request. Your selection is saved for retry.' };
}

function createExtensionInstanceId(): string {
  const randomId = globalThis.crypto?.randomUUID?.()
    ?? `${Date.now()}-${Math.random().toString(36).slice(2)}-${Math.random().toString(36).slice(2)}`;
  return `pfi_${randomId}`;
}

async function getExtensionInstanceId(): Promise<string> {
  if (!extensionInstanceIdPromise) {
    extensionInstanceIdPromise = (async () => {
      const result = await chrome.storage.local.get(EXTENSION_INSTANCE_ID_KEY);
      const existing = result[EXTENSION_INSTANCE_ID_KEY];
      if (typeof existing === 'string' && existing.trim()) return existing;

      const extensionInstanceId = createExtensionInstanceId();
      await chrome.storage.local.set({ [EXTENSION_INSTANCE_ID_KEY]: extensionInstanceId });
      console.log('[PostFlow] Created extension instance ID:', extensionInstanceId);
      return extensionInstanceId;
    })();
  }

  return extensionInstanceIdPromise;
}

async function getClerkUserId(): Promise<string | null> {
  const result = await chrome.storage.local.get('clerkUserId');
  return (result.clerkUserId as string) ?? null;
}

async function getExtensionName(): Promise<string> {
  const result = await chrome.storage.local.get(EXTENSION_NAME_KEY);
  return typeof result[EXTENSION_NAME_KEY] === 'string'
    ? result[EXTENSION_NAME_KEY].trim()
    : '';
}

// Uses shared authentication and URL fallback; detailed failures are opt-in for UI workflows.
async function apiFetch(
  path: string,
  body?: Record<string, unknown>,
  method?: string,
  includeFailureDetails = false,
) {
  if (!path || !path.startsWith('/')) {
    console.warn('[PostFlow] Refusing API call with invalid path:', path);
    return includeFailureDetails ? { apiFetchError: true, status: 400 } : null;
  }

  const [clerkUserId, extensionInstanceId] = await Promise.all([
    getClerkUserId(),
    getExtensionInstanceId(),
  ]);
  if (!clerkUserId) {
    console.warn('[PostFlow] No user ID found — skipping API call:', path);
    return includeFailureDetails ? { apiFetchError: true, status: 401 } : null;
  }

  const httpMethod = method || (body ? 'POST' : 'GET');
  const urls = [`${API_BASE_URL}${path}`];
  if (BUILD_ENV === 'development') {
    try {
      const apiUrl = new URL(API_BASE_URL);
      if (apiUrl.hostname === 'localhost') {
        urls.push(`${apiUrl.protocol}//127.0.0.1:${apiUrl.port}${path}`);
      }
    } catch {
      // The build script validates API_BASE_URL; keep the primary URL if it is malformed.
    }
  }

  let lastError: unknown;
  for (const url of urls) {
    try {
      const response = await fetch(url, {
        method: httpMethod,
        headers: {
          'Content-Type': 'application/json',
          'x-clerk-user-id': clerkUserId,
          'x-extension-instance-id': extensionInstanceId,
        },
        body: body ? JSON.stringify(body) : undefined,
      });

      // Handle empty responses (like 200 OK with no JSON)
      const text = await response.text();
      if (!response.ok) {
        console.warn('[PostFlow] API error', {
          status: response.status,
          method: httpMethod,
          path,
          url,
          response: text.slice(0, 300),
        });
        return includeFailureDetails
          ? { apiFetchError: true, status: response.status }
          : null;
      }

      return text ? JSON.parse(text) : null;
    } catch (err) {
      lastError = err;
    }
  }

  const errorMessage = lastError instanceof Error ? lastError.message : String(lastError);
  console.error(
    `[PostFlow] Network error: ${httpMethod} ${urls[0]} (${path}) - ${errorMessage}`,
    lastError,
  );
  return includeFailureDetails ? { apiFetchError: true, status: 0 } : null;
}

// Reads persisted review state and submits only selected, valid normalized numbers.
async function syncPhoneNumbersToBackend(): Promise<PhoneSyncResponse> {
  const stored = await chrome.storage.local.get('phoneCollectorState');
  const state = stored.phoneCollectorState as PhoneCollectorState | undefined;
  const selectedNumbers = Array.from(new Set(
    (state?.numbers ?? [])
      .filter((number) =>
        number.status === 'valid' && number.selected &&
        typeof number.normalized === 'string' && /^\+[1-9]\d{1,14}$/.test(number.normalized),
      )
      .map((number) => number.normalized!),
  ));

  if (!selectedNumbers.length) {
    logPhoneSync('warn', 'Sync stopped: no valid numbers are selected.', { code: 'NO_NUMBERS_SELECTED' });
    return {
      ok: false,
      code: 'NO_NUMBERS_SELECTED',
      error: 'Select at least one valid number before syncing.',
    };
  }
  if (!state?.source || !['facebook', 'generic'].includes(state.source.type) || !state.source.url) {
    logPhoneSync('error', 'Sync stopped: collection source is missing.', { code: 'INVALID_RESPONSE' });
    return {
      ok: false,
      code: 'INVALID_RESPONSE',
      error: 'The collection source is missing. Collect the numbers again before syncing.',
    };
  }

  logPhoneSync('info', 'Sending selected numbers to PostFlow.', { selected: selectedNumbers.length });
  const response = await apiFetch(
    '/api/phone-contacts/sync',
    { numbers: selectedNumbers, source: state.source },
    'POST',
    true,
  );
  if (isApiFetchFailure(response)) {
    const error = phoneSyncErrorForStatus(response.status);
    logPhoneSync('error', 'PostFlow sync request failed.', {
      ...(error.code ? { code: error.code } : {}),
      ...(typeof error.httpStatus === 'number' ? { httpStatus: error.httpStatus } : {}),
    });
    return error;
  }
  if (!isPhoneSyncResult(response)) {
    logPhoneSync('error', 'PostFlow returned an unexpected sync result.', { code: 'INVALID_RESPONSE' });
    return {
      ok: false,
      code: 'INVALID_RESPONSE',
      error: 'PostFlow returned an unexpected sync result. Your selection is saved for retry.',
    };
  }
  logPhoneSync('info', 'Sync response received.', {
    added: response.added,
    alreadyExisted: response.alreadyExisted,
    invalid: response.invalid,
  });
  return { ok: true, result: response };
}

// Locates collector scripts next to the service worker in either extension layout.
function getPhoneCollectorScriptFiles(): string[] {
  const background = chrome.runtime.getManifest().background;
  const serviceWorkerPath = background && "service_worker" in background
    ? background.service_worker
    : "";
  const scriptDirectory = serviceWorkerPath.includes("/")
    ? serviceWorkerPath.slice(0, serviceWorkerPath.lastIndexOf("/") + 1)
    : "";
  return [
    "libphonenumber-max.js",
    "phone-collector/phone-extractor.js",
    "phone-collector/phone-normalizer.js",
    "phone-collector/content.js",
  ].map((path) => `${scriptDirectory}${path}`);
}

// Scans the current HTTP(S) tab by installing the collector into its isolated content context.
async function collectPhoneNumbersFromActiveTab(): Promise<PhoneCollectionResponse> {
  try {
    const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    if (tab?.id === undefined || !tab.url) {
      return { ok: false, code: "NO_ACTIVE_TAB", error: "No active page is available." };
    }

    let pageUrl: URL;
    try {
      pageUrl = new URL(tab.url);
    } catch {
      return { ok: false, code: "UNSUPPORTED_PAGE", error: "This page cannot be scanned." };
    }
    if (pageUrl.protocol !== "http:" && pageUrl.protocol !== "https:") {
      return {
        ok: false,
        code: "UNSUPPORTED_PAGE",
        error: "Browser pages and local files cannot be scanned.",
      };
    }

    let collectorReady = false;
    try {
      const ping = await chrome.tabs.sendMessage(tab.id, { type: "PHONE_COLLECTOR_PING" });
      collectorReady = ping?.collectorReady === true;
    } catch {
      // A missing content script is expected on pages where the collector has not run yet.
    }

    if (!collectorReady) {
      try {
        await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          files: getPhoneCollectorScriptFiles(),
        });
      } catch {
        return {
          ok: false,
          code: "CONTENT_SCRIPT_UNAVAILABLE",
          error: "Unable to scan this page. Reload it and try again.",
        };
      }
    }

    try {
      const response = await chrome.tabs.sendMessage(tab.id, {
        type: "PHONE_COLLECTOR_COLLECT",
      }) as PhoneCollectionResponse | undefined;
      return response?.ok
        ? response
        : {
            ok: false,
            code: "COLLECTION_FAILED",
            error: response?.error ?? "Could not collect numbers from this page.",
          };
    } catch {
      return {
        ok: false,
        code: "CONTENT_SCRIPT_UNAVAILABLE",
        error: "The page collector did not respond. Reload the page and try again.",
      };
    }
  } catch {
    return {
      ok: false,
      code: "COLLECTION_FAILED",
      error: "Could not access the active page.",
    };
  }
}

async function updateJobStatus(
  jobId: string,
  body: {
    status: string;
    error?: string;
    submissionResult?: {
      status: 'PUBLISHED' | 'PENDING_APPROVAL' | 'UNKNOWN';
      postUrl?: string;
      reason?: string;
    };
  },
) {
  if (body.status === 'RUNNING') {
    await chrome.storage.local.set({ extensionWorkerStatus: 'PUBLISHING' });
  } else if (body.status === 'SUCCESS' || body.status === 'FAILED' || body.status === 'CANCELED') {
    await chrome.storage.local.set({ extensionWorkerStatus: 'IDLE' });
  }
  return apiFetch(`/api/jobs/${jobId}/status`, body);
}

// ── Registration ──

async function registerExtension() {
  const extensionName = await getExtensionName();
  const result = await apiFetch(
    '/api/extensions/register',
    extensionName ? { extensionName } : undefined,
    'POST',
  );
  if (result) {
    await chrome.alarms.clear(REGISTER_RETRY_ALARM);
    console.log('[PostFlow] Registered with backend:', result._id);
    void refreshFacebookSession();
    return true;
  }
  chrome.alarms.create(REGISTER_RETRY_ALARM, {
    delayInMinutes: REGISTER_RETRY_DELAY_MINUTES,
  });
  return false;
}

// ── Heartbeat ──

async function sendHeartbeat() {
  const extensionName = await getExtensionName();
  const result = await apiFetch(
    '/api/extensions/heartbeat',
    extensionName ? { extensionName } : undefined,
    'POST',
  );
  if (result) {
    console.log('[PostFlow] Heartbeat sent at', new Date().toISOString());
  }
}

// ── Session reporting ──

type FacebookConnectionSessionResponse = {
  connection?: {
    status?: string;
    workerStatus?: string;
    facebookUserId?: string;
    detectedFacebookUserId?: string;
  };
};

let facebookIdentityVerified = false;
let facebookConnectionStatus = 'UNKNOWN';
let facebookIdentityCheckPromise: Promise<boolean> | null = null;

async function reportSession(sessionDetected: boolean, facebookUserId?: string | null) {
  const normalizedFacebookUserId = typeof facebookUserId === 'string' && facebookUserId.trim()
    ? facebookUserId.trim()
    : undefined;
  const verificationPromise = (async () => {
    const result = await apiFetch('/api/extensions/session', {
      sessionDetected,
      ...(normalizedFacebookUserId ? { facebookUserId: normalizedFacebookUserId } : {}),
    }) as FacebookConnectionSessionResponse | null;
    const connection = result?.connection;
    facebookConnectionStatus = connection?.status ?? 'UNKNOWN';
    facebookIdentityVerified = Boolean(
      sessionDetected &&
      connection?.status === 'CONNECTED' &&
      connection.facebookUserId &&
      connection.detectedFacebookUserId &&
      connection.facebookUserId === connection.detectedFacebookUserId,
    );
    await chrome.storage.local.set({
      facebookIdentityVerified,
      facebookConnectionStatus,
      extensionWorkerStatus: connection?.workerStatus ?? (facebookIdentityVerified ? 'IDLE' : 'UNKNOWN'),
      expectedFacebookUserId: connection?.facebookUserId ?? null,
      detectedFacebookUserId: connection?.detectedFacebookUserId ?? normalizedFacebookUserId ?? null,
    });

    if (facebookIdentityVerified) {
      console.log('[PostFlow] Facebook identity verified:', connection?.facebookUserId);
      void checkPendingJobs();
    } else {
      console.warn('[PostFlow] Facebook identity verification failed', {
        sessionDetected,
        facebookUserId: normalizedFacebookUserId,
        status: facebookConnectionStatus,
        expectedFacebookUserId: connection?.facebookUserId,
      });
    }
    return facebookIdentityVerified;
  })();
  facebookIdentityCheckPromise = verificationPromise;
  return verificationPromise;
}

async function refreshFacebookSession() {
  try {
    const cookie = await chrome.cookies.get({
      url: 'https://www.facebook.com/',
      name: 'c_user',
    });
    const rawValue = cookie?.value?.trim() ?? '';
    let facebookUserId: string | null = null;
    try {
      const decodedValue = decodeURIComponent(rawValue);
      facebookUserId = /^\d+$/.test(decodedValue) ? decodedValue : null;
    } catch {
      facebookUserId = /^\d+$/.test(rawValue) ? rawValue : null;
    }
    return reportSession(Boolean(facebookUserId), facebookUserId);
  } catch (error) {
    console.warn('[PostFlow] Could not read Facebook session cookie', error);
    return false;
  }
}

chrome.cookies.onChanged.addListener((changeInfo) => {
  const domain = changeInfo.cookie.domain.replace(/^\./, '').toLowerCase();
  const isFacebookDomain = domain === 'facebook.com' || domain.endsWith('.facebook.com');
  if (changeInfo.cookie.name !== 'c_user' || !isFacebookDomain) return;
  void refreshFacebookSession();
});

type ExtensionWorkerStatus =
  | 'ONLINE'
  | 'OFFLINE'
  | 'IDLE'
  | 'PUBLISHING'
  | 'BLOCKED'
  | 'LOGIN_REQUIRED'
  | 'ACCOUNT_MISMATCH'
  | 'CHECKPOINT_OR_VERIFICATION'
  | 'CAPTCHA_OR_CHALLENGE'
  | 'MANUAL_INTERVENTION_REQUIRED';

async function reportWorkerStatus(workerStatus: ExtensionWorkerStatus, reason?: string) {
  await chrome.storage.local.set({
    extensionWorkerStatus: workerStatus,
    extensionWorkerReason: reason ? reason.slice(0, 500) : null,
  });
  const result = await apiFetch('/api/extensions/status', {
    workerStatus,
    ...(reason ? { reason: reason.slice(0, 500) } : {}),
  });
  if (result) {
    console.log('[PostFlow] Worker status reported:', workerStatus);
  }
}

function workerStatusForPublishFailure(status: unknown): ExtensionWorkerStatus {
  switch (status) {
    case 'TEMPORARY_BLOCK':
      return 'BLOCKED';
    case 'CAPTCHA_OR_CHALLENGE':
      return 'CAPTCHA_OR_CHALLENGE';
    case 'CHECKPOINT_OR_VERIFICATION':
      return 'CHECKPOINT_OR_VERIFICATION';
    case 'LOGIN_REQUIRED':
      return 'LOGIN_REQUIRED';
    default:
      return 'MANUAL_INTERVENTION_REQUIRED';
  }
}

async function waitForVerifiedFacebookIdentity(timeoutMs = 5000): Promise<boolean> {
  const startedAt = Date.now();
  while (Date.now() - startedAt < timeoutMs) {
    if (facebookIdentityVerified) return true;
    if (facebookIdentityCheckPromise) return facebookIdentityCheckPromise;
    await new Promise((resolve) => setTimeout(resolve, 100));
  }
  return false;
}

// ── Group storage (existing logic) ──

let pendingGroupSync: Promise<unknown> = Promise.resolve();

async function syncGroupsToBackend(groups: FacebookGroup[]) {
  if (!(await waitForVerifiedFacebookIdentity())) {
    console.warn('[PostFlow] Refusing group sync until Facebook identity is verified', {
      status: facebookConnectionStatus,
    });
    await chrome.storage.local.set({ groupsSyncStatus: 'identity-required' });
    return null;
  }
  const result = await apiFetch('/api/groups/sync', {
    groups: groups.map((g) => ({
      externalId: g.id,
      name: g.name,
      url: g.url,
      numericId: g.numericId,
    })),
  });
  if (result) {
    await chrome.storage.local.set({
      groupsSyncStatus: 'synced',
      groupsSyncCount: groups.length,
      groupsLastSyncedAt: Date.now(),
    });
    console.log('[PostFlow] Groups synced to backend:', result);
  } else {
    await chrome.storage.local.set({ groupsSyncStatus: 'error' });
  }
  return result;
}

function normalizeStoredGroupName(text: string): string {
  return text
    .replace(/[\u200e\u200f\u202a-\u202e]/g, '')
    .replace(/\s+/g, ' ')
    .trim();
}

function isNoisyStoredGroupName(text: string): boolean {
  const normalized = normalizeStoredGroupName(text).toLowerCase();
  return [
    'غير مقروءة',
    'مطلوب الموافقة',
    'approval required',
    'requires approval',
    'unread',
    'new post',
    'learn more about this group',
    'about this group',
  ].some((needle) => normalized.includes(needle.toLowerCase()));
}

function shouldReplaceStoredGroupName(prev: FacebookGroup | undefined, next: FacebookGroup): boolean {
  if (!prev) return true;

  const nextName = normalizeStoredGroupName(next.name);
  const prevName = normalizeStoredGroupName(prev.name);
  if (!nextName || nextName.length < 2) return false;

  return (
    isNoisyStoredGroupName(prevName) ||
    prevName === prev.id ||
    prevName === prev.numericId ||
    (
      next.nameSource === 'graphql' &&
      prevName.length > nextName.length + 20
    )
  );
}

chrome.runtime.onConnect.addListener((port) => {
  if (port.name !== 'postflow-content') return;

  port.onMessage.addListener(async (message) => {
    if (message.type !== 'GROUPS_DETECTED') return;

    if (!(await waitForVerifiedFacebookIdentity())) {
      console.warn('[PostFlow] Ignoring groups detected before Facebook identity verification');
      return;
    }

    const incoming = message.groups as FacebookGroup[];

    const result = await chrome.storage.local.get('facebookGroups');
    const existing = (result.facebookGroups ?? []) as FacebookGroup[];

    const merged = new Map<string, FacebookGroup>();
    for (const g of existing) merged.set(g.id, g);
    for (const g of incoming) {
      const prev = merged.get(g.id);
      const replaceName = shouldReplaceStoredGroupName(prev, g);
      merged.set(g.id, {
        ...prev,
        ...g,
        name: replaceName ? normalizeStoredGroupName(g.name) : prev?.name ?? normalizeStoredGroupName(g.name),
        nameSource: replaceName ? g.nameSource : prev?.nameSource ?? g.nameSource,
        numericId: g.numericId ?? prev?.numericId,
        url: `https://www.facebook.com/groups/${g.id}/`,
      });
    }

    const mergedList = Array.from(merged.values());
    await chrome.storage.local.set({ facebookGroups: mergedList });
    console.log(`[PostFlow] Storage: ${mergedList.length} groups total`);

    // Sync to backend
    pendingGroupSync = syncGroupsToBackend(mergedList).catch((err) => {
      console.error('[PostFlow] Group backend sync failed:', err);
    });
  });

  port.onDisconnect.addListener(() => {
    console.log('[PostFlow] Content script disconnected');
  });
});

// ── Session + sync messages ──

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'SYNC_PHONE_NUMBERS') {
    if (sender.tab) {
      sendResponse({
        ok: false,
        code: 'FORBIDDEN',
        error: 'Phone sync can only be started from the extension popup.',
      } satisfies PhoneSyncResponse);
      return;
    }
    void (async () => {
      try {
        logPhoneSync('info', 'Sync request received by the extension worker.');
        const response = await syncPhoneNumbersToBackend();
        sendResponse(response);
      } catch {
        logPhoneSync('error', 'Extension worker could not complete the sync.', { code: 'NETWORK_ERROR' });
        sendResponse({
          ok: false,
          code: 'NETWORK_ERROR',
          error: 'Could not sync with PostFlow. Your selection is saved for retry.',
        } satisfies PhoneSyncResponse);
      }
    })();
    return true;
  }

  if (message.type === 'COLLECT_PHONE_NUMBERS') {
    void collectPhoneNumbersFromActiveTab()
      .then(sendResponse)
      .catch(() => sendResponse({
        ok: false,
        code: 'COLLECTION_FAILED',
        error: 'Could not collect numbers from the active page.',
      }));
    return true;
  }

  if (message.type === 'POSTING_LOG' && message.entry) {
    console.log('[PostFlow][posting-log]', message.entry);
    void (async () => {
      const result = await chrome.storage.local.get('postingLogs');
      const logs = Array.isArray(result.postingLogs) ? result.postingLogs : [];
      logs.push({ ...message.entry, tabId: sender.tab?.id ?? null });
      // Keep the latest entries only so a long-running extension cannot grow storage forever.
      await chrome.storage.local.set({ postingLogs: logs.slice(-500) });
    })().catch((err) => console.warn('[PostFlow] Could not save posting log:', err));
    return;
  }

  if (message.type === 'FACEBOOK_SESSION_STATUS') {
    void reportSession(
      message.sessionDetected as boolean,
      typeof message.facebookUserId === 'string' ? message.facebookUserId : null,
    );
  }

  if (message.type === 'TRIGGER_GROUP_SYNC') {
    (async () => {
      try {
        if (!(await waitForVerifiedFacebookIdentity())) {
          await chrome.storage.local.set({ groupsSyncStatus: 'identity-required' });
          sendResponse({ ok: false, error: 'Facebook identity verification required' });
          return;
        }
        await chrome.storage.local.set({ groupsSyncStatus: 'syncing' });
        // 1. Immediately flush whatever is already cached in storage to the backend.
        //    This handles the race condition where groups were discovered before the
        //    user logged in (so the earlier sync was silently skipped due to missing userId).
        const result = await chrome.storage.local.get('facebookGroups');
        const cached = (result.facebookGroups ?? []) as FacebookGroup[];
        if (cached.length > 0) {
          console.log(`[PostFlow] Flushing ${cached.length} cached groups to backend`);
          await syncGroupsToBackend(cached);
        }

        // 2. Also tell open Facebook tabs to do a fresh DOM scan for new groups.
        const tabs = await chrome.tabs.query({ url: '*://*.facebook.com/*' });
        if (!tabs.length) {
          console.warn('[PostFlow] Sync requested but no Facebook tabs are open');
          await chrome.storage.local.set({ groupsSyncStatus: 'not-synced' });
          sendResponse({ ok: true, scanned: false });
          return;
        }
        
        const scanPromises = tabs.map(tab => {
          if (tab.id !== undefined) {
            return chrome.tabs.sendMessage(tab.id, { type: 'SCAN_NOW' }).catch(() => null);
          }
          return Promise.resolve(null);
        });
        
        await Promise.all(scanPromises);
        // GROUPS_DETECTED is handled asynchronously through the runtime port.
        // Wait for its backend upload before telling the web app that sync ended.
        await pendingGroupSync;
        console.log(`[PostFlow] Finished scan on ${tabs.length} Facebook tab(s)`);
        sendResponse({ ok: true, scanned: true });
      } catch (err) {
        console.error('[PostFlow] Error during group sync:', err);
        sendResponse({ ok: false, error: String(err) });
      }
    })();
    return true; // Keep message channel open for sendResponse
  }
  if (message.type === 'SAVE_EXTENSION_NAME') {
    void (async () => {
      const extensionName = typeof message.extensionName === 'string'
        ? message.extensionName.trim()
        : '';
      await chrome.storage.local.set({ [EXTENSION_NAME_KEY]: extensionName });
      const registered = await registerExtension();
      sendResponse({ ok: registered });
    })().catch((error) => {
      console.error('[PostFlow] Could not save extension name:', error);
      sendResponse({ ok: false, error: 'Could not save extension name' });
    });
    return true;
  }
  if (message.type === 'TRIGGER_JOB_CHECK') {
    checkPendingJobs();
  }
  if (message.type === 'GET_JOB_STATUS' && typeof message.jobId === 'string') {
    void apiFetch(`/api/jobs/${message.jobId}`)
      .then((job) => sendResponse({ ok: Boolean(job), job }))
      .catch((error) => sendResponse({ ok: false, error: error?.message ?? 'Could not fetch job status' }));
    return true;
  }
  if (message.type === 'RESUME_PUBLISH_QUEUE') {
    publishQueuePaused = null;
    void chrome.storage.local.remove('publishQueuePaused');
    void reportWorkerStatus('IDLE');
    checkPendingJobs();
  }
});

// ── Job Execution Flow ──

let isProcessingJob = false;
let isCheckingPendingPost = false;
let isFacebookSyncBusy = false;
let publishQueuePaused: {
  reason: string;
  status?: string;
  jobId?: string;
  pausedAt: number;
} | null = null;
let pendingCheckSequence = 0;
let finishExecutionHandshake: (() => void) | null = null;
let activeExecution: {
  jobId: string;
  tabId: number;
  group?: any;
  post?: any;
} | null = null;

void chrome.storage.local.get('publishQueuePaused').then((result) => {
  const paused = result.publishQueuePaused as Partial<NonNullable<typeof publishQueuePaused>> | undefined;
  if (paused && typeof paused.reason === 'string' && typeof paused.pausedAt === 'number') {
    publishQueuePaused = {
      reason: paused.reason,
      status: typeof paused.status === 'string' ? paused.status : undefined,
      jobId: typeof paused.jobId === 'string' ? paused.jobId : undefined,
      pausedAt: paused.pausedAt,
    };
    console.warn('[PostFlow] Restored paused publishing queue state', publishQueuePaused);
  }
}).catch(() => undefined);

async function checkPendingJobs() {
  if (!facebookIdentityVerified) {
    console.log('[PostFlow] Publishing blocked until Facebook identity is verified', {
      status: facebookConnectionStatus,
    });
    return;
  }
  if (publishQueuePaused) {
    console.warn('[PostFlow] Publishing queue is paused; skipping job check', publishQueuePaused);
    return;
  }
  if (isProcessingJob || isFacebookSyncBusy) {
    console.log('[PostFlow] Skipping job check while Facebook navigation is busy', {
      isProcessingJob,
      isFacebookSyncBusy,
    });
    return;
  }
  isProcessingJob = true;

  const job = await apiFetch('/api/jobs/next');
  if (!job || !job.postId) {
    console.log('[PostFlow] No pending jobs');
    isProcessingJob = false;
    return;
  }

  console.log('[PostFlow] Found pending job:', job._id);

  try {
    // 1. Mark as running
    await updateJobStatus(job._id, { status: 'RUNNING' });

    // 2. Find or create a Facebook tab for the group
    const targetUrl = getSafeFacebookGroupUrl(job.groupId, job.groupId.url);
    if (!targetUrl) {
      console.error('[PostFlow] Refusing to navigate to invalid Facebook group URL', {
        jobId: job._id,
        group: job.groupId,
      });
      await updateJobStatus(job._id, { status: 'FAILED', error: 'Invalid Facebook group URL' });
      isProcessingJob = false;
      return;
    }
    
    const fbTab = await openFacebookGroupTab(targetUrl);

    const tabId = fbTab.id;
    if (!tabId) {
      await updateJobStatus(job._id, { status: 'FAILED', error: 'Could not get tab ID' });
      isProcessingJob = false;
      activeExecution = null;
      return;
    }
    const readyTabId = tabId;
    activeExecution = {
      jobId: job._id,
      tabId: readyTabId,
      group: job.groupId,
      post: job.postId,
    };

    // tabs.update/tabs.create resolves before the old Facebook document has
    // necessarily been replaced. Sending EXECUTE_JOB immediately can make
    // the previous page open its composer. Wait for the target group document.
    const targetReady = await waitForFacebookTabDocument(readyTabId, targetUrl, POSTING_TIMING.facebookTabReadyTimeoutMs);
    if (!targetReady) {
      console.error('[PostFlow] Target Facebook group page did not finish loading', targetUrl);
      await updateJobStatus(job._id, {
        status: 'FAILED',
        error: 'Target Facebook group page did not finish loading',
      });
      isProcessingJob = false;
      activeExecution = null;
      return;
    }
    console.log('[PostFlow] Target Facebook group page is loaded; waiting for content script', targetUrl);

    const latestJob = await apiFetch(`/api/jobs/${job._id}`) as { status?: string } | null;
    if (latestJob?.status === 'CANCEL_REQUESTED') {
      console.warn('[PostFlow] Job was canceled before Facebook execution started:', job._id);
      await updateJobStatus(job._id, { status: 'CANCELED' });
      isProcessingJob = false;
      activeExecution = null;
      checkPendingJobs();
      return;
    }

      let sent = false;
      let sendInFlight = false;
      let timeoutHandle: ReturnType<typeof setTimeout>;
      let retryHandle: ReturnType<typeof setInterval> | null = null;

    function sendExecuteJob(force = false) {
        if (activeExecution?.jobId !== job._id || activeExecution?.tabId !== readyTabId) {
          console.warn('[PostFlow] Skipping stale EXECUTE_JOB send', {
            jobId: job._id,
            tabId: readyTabId,
            activeExecution,
          });
          return;
        }
        if (sent && !force) return;
        if (sendInFlight) {
          console.log('[PostFlow] Skipping overlapping EXECUTE_JOB send', job._id);
          return;
        }
        sendInFlight = true;
        console.log('[PostFlow] Sending EXECUTE_JOB to Facebook tab', {
          tabId: readyTabId,
          jobId: job._id,
          force,
        });
        chrome.tabs.sendMessage(readyTabId, {
          type: 'EXECUTE_JOB',
          jobId: job._id,
          post: job.postId,
          group: job.groupId,
        }).then(() => {
          sendInFlight = false;
          sent = true;
          console.log('[PostFlow] Facebook content script accepted EXECUTE_JOB');
        }).catch(() => {
          sendInFlight = false;
          sent = false;
          console.log('[PostFlow] Facebook content script is not ready; retrying');
        });
      }

      function onMessage(message: any, sender: chrome.runtime.MessageSender) {
        if (message.type === 'CONTENT_SCRIPT_READY' && sender.tab?.id === readyTabId) {
          if (activeExecution?.jobId !== job._id || activeExecution?.tabId !== readyTabId) {
            console.warn('[PostFlow] Ignoring stale content-script ready handler', {
              jobId: job._id,
              tabId: readyTabId,
              activeExecution,
            });
            cleanup();
            return;
          }
          // Facebook can tear down the content script when the composer is
          // clicked. Force delivery to the replacement content-script instance.
          console.log('[PostFlow] Facebook content script ready; resuming job', job._id);
          sendExecuteJob(true);
        }
      }

    function cleanup() {
        chrome.runtime.onMessage.removeListener(onMessage);
        if (retryHandle) clearInterval(retryHandle);
        if (finishExecutionHandshake === cleanup) finishExecutionHandshake = null;
      }

    finishExecutionHandshake = cleanup;

    chrome.runtime.onMessage.addListener(onMessage);
    sendExecuteJob();
    retryHandle = setInterval(sendExecuteJob, POSTING_TIMING.facebookMessageRetryIntervalMs);

    timeoutHandle = setTimeout(async () => {
        if (sent) return;
        cleanup();
        console.error('[PostFlow] Timed out waiting for Facebook tab to be ready');
        await updateJobStatus(job._id, {
          status: 'FAILED',
          error: 'Timed out waiting for Facebook page to load',
        });
        isProcessingJob = false;
        activeExecution = null;
    }, POSTING_TIMING.facebookTabReadyTimeoutMs);

  } catch (err) {
    console.error('[PostFlow] Error processing job:', err);
    await updateJobStatus(job._id, { 
      status: 'FAILED', 
      error: 'Extension error while processing job' 
    });
    isProcessingJob = false;
    activeExecution = null;
  }
}

function getSafeFacebookGroupUrl(group: any, fallback?: string): string | null {
  const candidate = typeof fallback === 'string' ? fallback : group?.url;
  let groupId = typeof group?.externalId === 'string' ? group.externalId : '';
  try {
    const url = candidate ? new URL(candidate) : null;
    if (!groupId) groupId = url?.pathname.match(/^\/groups\/([^/]+)/i)?.[1] ?? '';
  } catch {
    // Rebuild from externalId when the stored URL is malformed.
  }
  if (!groupId || /[/?#]/.test(groupId)) return null;
  return `https://www.facebook.com/groups/${groupId}/`;
}

async function openFacebookGroupTab(targetUrl: string): Promise<chrome.tabs.Tab> {
  const tabs = await chrome.tabs.query({ url: '*://*.facebook.com/*' });
  const existingTab = tabs.find((tab) => tab.id !== undefined);
  let lastError: unknown;

  if (existingTab?.id !== undefined) {
    for (let attempt = 0; attempt < TAB_ACTION_RETRY_COUNT; attempt += 1) {
      try {
        const updatedTab = await chrome.tabs.update(existingTab.id, {
          url: targetUrl,
          active: true,
        });
        if (updatedTab) return updatedTab;
        throw new Error('Facebook tab navigation returned no tab');
      } catch (error) {
        lastError = error;
        console.warn('[PostFlow] Facebook tab navigation is temporarily unavailable; retrying', {
          attempt: attempt + 1,
          error: error instanceof Error ? error.message : String(error),
        });
        await new Promise((resolve) => setTimeout(resolve, TAB_ACTION_RETRY_DELAY_MS));
      }
    }
  }

  for (let attempt = 0; attempt < TAB_ACTION_RETRY_COUNT; attempt += 1) {
    try {
      return await chrome.tabs.create({ url: targetUrl, active: true });
    } catch (error) {
      lastError = error;
      console.warn('[PostFlow] Facebook tab creation is temporarily unavailable; retrying', {
        attempt: attempt + 1,
        error: error instanceof Error ? error.message : String(error),
      });
      await new Promise((resolve) => setTimeout(resolve, TAB_ACTION_RETRY_DELAY_MS));
    }
  }

  throw lastError instanceof Error
    ? lastError
    : new Error('Could not open a Facebook tab');
}

async function waitForFacebookTabDocument(tabId: number, targetUrl: string, timeoutMs: number): Promise<boolean> {
  const startedAt = Date.now();
  let targetPath = '';
  try {
    targetPath = new URL(targetUrl).pathname.replace(/\/+$/, '').toLowerCase();
  } catch {
    return false;
  }

  while (Date.now() - startedAt < timeoutMs) {
    try {
      const tab = await chrome.tabs.get(tabId);
      const currentUrl = tab.url ?? '';
      const currentPath = currentUrl ? new URL(currentUrl).pathname.replace(/\/+$/, '').toLowerCase() : '';
      if (tab.status === 'complete' && currentPath === targetPath) return true;
    } catch {
      return false;
    }
    await new Promise((resolve) => setTimeout(resolve, 200));
  }
  return false;
}

function isCurrentExecutionResult(message: any, sender: chrome.runtime.MessageSender) {
  if (!activeExecution) {
    console.warn('[PostFlow] Ignoring job result with no active execution:', message.type, message.jobId);
    return false;
  }
  if (message.jobId !== activeExecution.jobId) {
    console.warn('[PostFlow] Ignoring stale job result for non-active job:', {
      type: message.type,
      receivedJobId: message.jobId,
      activeJobId: activeExecution.jobId,
    });
    return false;
  }
  if (sender.tab?.id !== activeExecution.tabId) {
    console.warn('[PostFlow] Ignoring job result from non-active tab:', {
      type: message.type,
      jobId: message.jobId,
      receivedTabId: sender.tab?.id,
      activeTabId: activeExecution.tabId,
    });
    return false;
  }
  return true;
}

// Handle JOB result messages from content script
chrome.runtime.onMessage.addListener((message, sender) => {
  if (message.type === 'JOB_SUCCESS') {
    if (!isCurrentExecutionResult(message, sender)) return;
    void (async () => {
      console.log('[PostFlow] Job succeeded:', message.jobId);
      const completedExecution = activeExecution;
      finishExecutionHandshake?.();
      await updateJobStatus(message.jobId, {
        status: 'SUCCESS',
        submissionResult: message.submissionResult,
      });
      isProcessingJob = false;
      activeExecution = null;

      const completedMediaUrls = Array.isArray(completedExecution?.post?.mediaUrls)
        ? completedExecution.post.mediaUrls
        : [];
      const completedPostHasVideo = completedMediaUrls.some((url: unknown) => typeof url === 'string' && url.startsWith('data:video/'));
      const shouldRunAutomaticPostLinkCheck = Boolean(
        completedExecution?.group &&
        completedExecution.post &&
        (
          (
            message.submissionResult?.status === 'PUBLISHED' &&
            !message.submissionResult.postUrl
          ) ||
          (
            message.submissionResult?.status === 'UNKNOWN' &&
            completedPostHasVideo
          )
        ),
      );

      if (shouldRunAutomaticPostLinkCheck && completedExecution?.group && completedExecution.post) {
        const syncPost: PendingFacebookPost = {
          id: message.jobId,
          groupId: String(completedExecution.group._id ?? completedExecution.group.id ?? ''),
          groupExternalId: completedExecution.group.externalId,
          groupUrl: completedExecution.group.url,
          status: 'PENDING_APPROVAL',
          content: completedExecution.post.content,
          submittedAt: new Date().toISOString(),
          mediaCount: Array.isArray(completedExecution.post.mediaUrls)
            ? completedExecution.post.mediaUrls.length
            : 0,
        };
        console.log('[PostFlow] Starting automatic post-link check after publish result', {
          jobId: message.jobId,
          publishStatus: message.submissionResult?.status,
          hasVideo: completedPostHasVideo,
        });
        const syncResult = await checkSinglePendingPost(syncPost);
        const shouldPersistAutomaticPostLinkCheck = message.submissionResult?.status === 'PENDING_APPROVAL' ||
          syncResult.status === 'PUBLISHED' ||
          (
            message.submissionResult?.status === 'UNKNOWN' &&
            completedPostHasVideo &&
            syncResult.status === 'STILL_PENDING' &&
            Boolean(syncResult.postUrl)
          );
        const updated = shouldPersistAutomaticPostLinkCheck
          ? await persistPendingSyncResult(syncPost, syncResult)
          : false;
        console.log('[PostFlow] Automatic post-link check finished', {
          jobId: message.jobId,
          status: syncResult.status,
          updated,
          persisted: shouldPersistAutomaticPostLinkCheck,
        });
      }

      checkPendingJobs();
    })();
  }
  if (message.type === 'JOB_FAILED') {
    if (!isCurrentExecutionResult(message, sender)) return;
    void (async () => {
      console.error('[PostFlow] Job failed:', message.jobId, message.error);
      finishExecutionHandshake?.();
      if (message.shouldPauseQueue || message.publishStatus) {
        void reportWorkerStatus(
          workerStatusForPublishFailure(message.publishStatus),
          message.error,
        );
      }
      if (message.shouldPauseQueue) {
        publishQueuePaused = {
          reason: message.error ?? 'Facebook publishing requires manual attention',
          status: message.publishStatus,
          jobId: message.jobId,
          pausedAt: Date.now(),
        };
        await chrome.storage.local.set({ publishQueuePaused });
        console.warn('[PostFlow] Publishing queue paused for manual attention', publishQueuePaused);
      }
      await updateJobStatus(message.jobId, { status: 'FAILED', error: message.error });
      isProcessingJob = false;
      activeExecution = null;
      if (!publishQueuePaused) checkPendingJobs();
    })();
  }
  if (message.type === 'JOB_CANCELED') {
    if (!isCurrentExecutionResult(message, sender)) return;
    void (async () => {
      console.warn('[PostFlow] Job canceled before Facebook submit:', message.jobId);
      finishExecutionHandshake?.();
      await updateJobStatus(message.jobId, { status: 'CANCELED' });
      isProcessingJob = false;
      activeExecution = null;
      checkPendingJobs();
    })();
  }
});

/** Navigate to one pending post's group and ask the Facebook content script to
 * perform the DOM match. This function intentionally does not update the API;
 * persistence belongs to the next feature phase. */
async function checkSinglePendingPost(post: PendingFacebookPost, lockAlreadyHeld = false): Promise<PendingPostSyncResult> {
  if (isProcessingJob) {
    return { status: 'CHECK_FAILED', reason: 'A new Facebook post is currently being published' };
  }
  if (isCheckingPendingPost) {
    return { status: 'CHECK_FAILED', reason: 'Another pending post check is already running' };
  }
  if (!lockAlreadyHeld && isFacebookSyncBusy) {
    return { status: 'CHECK_FAILED', reason: 'Another Facebook sync is already running' };
  }
  if (!lockAlreadyHeld) isFacebookSyncBusy = true;

  isCheckingPendingPost = true;
  const requestId = `pending-${++pendingCheckSequence}`;
  let syncTabId: number | undefined;
  try {
    const groupUrl = getSafeFacebookGroupUrl(post, post.groupUrl);
    if (!groupUrl) {
      return { status: 'CHECK_FAILED', reason: 'Invalid Facebook group URL' };
    }
    console.log('[PendingPostSync] Starting single post check', {
      postId: post.id,
      groupUrl,
      requestId,
    });
    // Status checks must never reuse or foreground the tab used for a new
    // publish. Reusing tabs here was the source of old posts appearing during
    // a different group's publish flow.
    let checkUrl = groupUrl;
    if (post.postUrl) {
      try {
        const savedUrl = new URL(post.postUrl);
        if (/^\/groups\/[^/]+\/(?:posts|pending_posts|permalink)\/[A-Za-z0-9_-]+/i.test(savedUrl.pathname)) {
          checkUrl = savedUrl.href;
        }
      } catch {
        // Fall back to the group feed when the saved pending URL is invalid.
      }
    }
    const fbTab = await chrome.tabs.create({ url: checkUrl, active: false });
    syncTabId = fbTab.id;

    if (!fbTab.id || !(await waitForFacebookTabAfterNavigation(fbTab.id, checkUrl, POSTING_TIMING.facebookTabReadyTimeoutMs))) {
      console.warn('[PendingPostSync] Facebook pending-post navigation failed', { postId: post.id, checkUrl });
      return { status: 'CHECK_FAILED', reason: 'Target Facebook group page did not finish loading' };
    }

    const startedAt = Date.now();
    while (Date.now() - startedAt < POSTING_TIMING.facebookTabReadyTimeoutMs) {
      try {
        console.log('[PendingPostSync] Asking Facebook content script to check post', {
          postId: post.id,
          tabId: fbTab.id,
          requestId,
        });
        const response = await chrome.tabs.sendMessage(fbTab.id, {
          type: 'CHECK_PENDING_POST',
          requestId,
          post,
        });
        if (response?.ok && response.result) {
          console.log('[PendingPostSync] Facebook content script returned result', {
            postId: post.id,
            result: response.result,
          });
          return response.result as PendingPostSyncResult;
        }
      } catch {
        // Content scripts can be replaced during navigation; retry until timeout.
      }
      await new Promise((resolve) => setTimeout(resolve, POSTING_TIMING.facebookMessageRetryIntervalMs));
    }
    return { status: 'CHECK_FAILED', reason: 'Timed out waiting for pending post matcher' };
  } catch (err: any) {
    return { status: 'CHECK_FAILED', reason: err?.message ?? 'Pending post check failed' };
  } finally {
    if (syncTabId !== undefined) {
      await chrome.tabs.remove(syncTabId).catch(() => undefined);
    }
    isCheckingPendingPost = false;
    if (!lockAlreadyHeld) isFacebookSyncBusy = false;
  }
}

/**
 * Wait for a real navigation cycle when reusing a tab. A same-path tab can
 * otherwise still report `complete` for the old Facebook document.
 */
async function waitForFacebookTabAfterNavigation(tabId: number, targetUrl: string, timeoutMs: number): Promise<boolean> {
  const startedAt = Date.now();
  let targetPath = '';
  let targetGroupPath = '';
  let targetPostIdentity = '';
  const targetIsPost = /\/groups\/[^/]+\/(?:posts|pending_posts|permalink)\/[A-Za-z0-9_-]+/i.test(targetUrl);
  try {
    const parsedTarget = new URL(targetUrl);
    targetPath = parsedTarget.pathname.replace(/\/+$/, '').toLowerCase();
    targetGroupPath = parsedTarget.pathname.match(/^\/groups\/[^/]+/i)?.[0].toLowerCase() ?? '';
    targetPostIdentity = parsedTarget.pathname.match(/^\/groups\/[^/]+\/(?:posts|pending_posts|permalink)\/([A-Za-z0-9_-]+)/i)?.[1] ?? '';
  } catch {
    return false;
  }

  while (Date.now() - startedAt < timeoutMs) {
    try {
      const tab = await chrome.tabs.get(tabId);
      const currentUrl = tab.url ?? '';
      const currentPath = currentUrl ? new URL(currentUrl).pathname.replace(/\/+$/, '').toLowerCase() : '';
      const currentPostIdentity = currentPath.match(/^\/groups\/[^/]+\/(?:posts|pending_posts|permalink)\/([A-Za-z0-9_-]+)/i)?.[1] ?? '';
      const landedOnTarget = currentPath === targetPath ||
        (targetIsPost && currentPath === targetGroupPath) ||
        (targetIsPost && targetPostIdentity && currentPostIdentity === targetPostIdentity);
      if (tab.status === 'complete' && landedOnTarget && Date.now() - startedAt >= 1500) return true;
    } catch {
      return false;
    }
    await new Promise((resolve) => setTimeout(resolve, 200));
  }
  return false;
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message.type !== 'TRIGGER_SINGLE_PENDING_SYNC' || !message.post) return;
  void checkSinglePendingPost(message.post as PendingFacebookPost)
    .then(async (result) => {
      const updated = await persistPendingSyncResult(message.post as PendingFacebookPost, result);
      console.log('[PendingPostSync] Single check persisted', {
        postId: message.post.id,
        status: result.status,
        updated,
      });
      sendResponse({ ok: true, result, updated });
    })
    .catch((err) => sendResponse({ ok: false, error: err?.message ?? 'Pending post sync failed' }));
  return true;
});

let isPendingBatchRunning = false;

/** Fetch and process a small pending-post batch without opening concurrent tabs. */
async function syncPendingPostsBatch(): Promise<Array<{ postId: string; result: PendingPostSyncResult; updated: boolean }>> {
  if (isPendingBatchRunning || isFacebookSyncBusy || isProcessingJob) return [];
  isPendingBatchRunning = true;
  isFacebookSyncBusy = true;

  try {
    const pendingPosts = await apiFetch('/api/jobs/pending?limit=10');
    if (!Array.isArray(pendingPosts)) {
      console.warn('[PendingPostSync] Could not fetch pending posts');
      return [];
    }

    const results: Array<{ postId: string; result: PendingPostSyncResult; updated: boolean }> = [];
    for (const post of pendingPosts as PendingFacebookPost[]) {
      let result: PendingPostSyncResult;
      try {
        result = await checkSinglePendingPost(post, true);
      } catch (err: any) {
        result = { status: 'CHECK_FAILED', reason: err?.message ?? 'Pending post check failed' };
      }

      const updated = await persistPendingSyncResult(post, result);
      results.push({ postId: post.id, result, updated });
      console.log('[PendingPostSync] Completed pending post check', {
        postId: post.id,
        status: result.status,
        updated,
      });
    }
    return results;
  } finally {
    isPendingBatchRunning = false;
    isFacebookSyncBusy = false;
  }
}

async function persistPendingSyncResult(post: PendingFacebookPost, result: PendingPostSyncResult): Promise<boolean> {
  const response = await apiFetch(`/api/jobs/${post.id}/pending-sync`, result);
  return Boolean(response);
}

let isEngagementBatchRunning = false;
let engagementCheckSequence = 0;
let isCheckingEngagement = false;

function normalizeStoredFacebookPostUrl(value: string): string | null {
  const markdownMatch = value.trim().match(/^\[[^\]]+\]\((https?:\/\/[^)]+)\)$/i);
  const candidate = markdownMatch?.[1] ?? value.trim();
  try {
    const url = new URL(candidate);
    if (!/facebook\.com$/i.test(url.hostname) && !/\.facebook\.com$/i.test(url.hostname)) return null;
    return url.href;
  } catch {
    return null;
  }
}

async function checkSinglePostEngagement(post: PublishedFacebookPost, lockAlreadyHeld = false): Promise<PostEngagementSyncResult> {
  if (isProcessingJob) {
    return { status: 'CHECK_FAILED', reason: 'A new Facebook post is currently being published' };
  }
  if (isCheckingEngagement || (!lockAlreadyHeld && isFacebookSyncBusy)) {
    return { status: 'CHECK_FAILED', reason: 'Another engagement check is already running' };
  }
  if (!lockAlreadyHeld) isFacebookSyncBusy = true;
  isCheckingEngagement = true;
  const requestId = `engagement-${++engagementCheckSequence}`;
  let syncTabId: number | undefined;
  const postUrl = normalizeStoredFacebookPostUrl(post.postUrl);
  if (!postUrl) {
    console.error('[PostAnalytics] Invalid stored Facebook post URL', { postId: post.id, postUrl: post.postUrl });
    isCheckingEngagement = false;
    if (!lockAlreadyHeld) isFacebookSyncBusy = false;
    return { status: 'CHECK_FAILED', reason: 'Stored Facebook post URL is invalid' };
  }
  try {
    console.log('[PostAnalytics] Opening published post', {
      postId: post.id,
      postUrl,
      requestId,
    });
    // Analytics runs in an isolated background tab. It must not navigate the
    // active publishing tab to a previously stored post URL.
    const fbTab = await chrome.tabs.create({ url: postUrl, active: false });
    syncTabId = fbTab.id;
    console.log('[PostAnalytics] Facebook tab opened', { tabId: fbTab.id, postId: post.id });
    const ready = Boolean(fbTab.id && await waitForFacebookTabAfterNavigation(fbTab.id, postUrl, POSTING_TIMING.facebookTabReadyTimeoutMs));
    console.log('[PostAnalytics] Facebook tab readiness result', { tabId: fbTab.id, postId: post.id, ready });
    if (!fbTab.id || !ready) {
      console.warn('[PostAnalytics] Facebook post navigation failed', { postId: post.id, postUrl });
      return { status: 'CHECK_FAILED', reason: 'Target Facebook post did not finish loading' };
    }

    const startedAt = Date.now();
    while (Date.now() - startedAt < POSTING_TIMING.facebookTabReadyTimeoutMs) {
      try {
        console.log('[PostAnalytics] Sending engagement check to Facebook tab', {
          postId: post.id,
          tabId: fbTab.id,
          requestId,
        });
        const response = await chrome.tabs.sendMessage(fbTab.id, {
          type: 'CHECK_POST_ENGAGEMENT', requestId, post: { ...post, postUrl },
        });
        console.log('[PostAnalytics] Facebook tab response received', { postId: post.id, tabId: fbTab.id, response });
        if (response?.ok && response.result) {
          console.log('[PostAnalytics] Engagement check completed', { postId: post.id, result: response.result });
          return response.result as PostEngagementSyncResult;
        }
      } catch (error) {
        console.log('[PostAnalytics] Facebook content script unavailable; retrying', {
          postId: post.id,
          tabId: fbTab.id,
          error: error instanceof Error ? error.message : String(error),
        });
        // The content script can be replaced while Facebook finishes navigation.
      }
      await new Promise((resolve) => setTimeout(resolve, POSTING_TIMING.facebookMessageRetryIntervalMs));
    }
    console.error('[PostAnalytics] Timed out waiting for Facebook engagement content script', {
      postId: post.id,
      tabId: fbTab.id,
    });
    return { status: 'CHECK_FAILED', reason: 'Timed out waiting for engagement counters' };
  } catch (err: any) {
    return { status: 'CHECK_FAILED', reason: err?.message ?? 'Engagement check failed' };
  } finally {
    if (syncTabId !== undefined) {
      await chrome.tabs.remove(syncTabId).catch(() => undefined);
    }
    isCheckingEngagement = false;
    if (!lockAlreadyHeld) isFacebookSyncBusy = false;
  }
}

async function syncPublishedEngagementBatch(postId?: string) {
  if (isEngagementBatchRunning || isFacebookSyncBusy || isProcessingJob) return [];
  isEngagementBatchRunning = true;
  isFacebookSyncBusy = true;
  try {
    const query = postId
      ? `/api/jobs/engagement-pending?limit=50&postId=${encodeURIComponent(postId)}`
      : '/api/jobs/engagement-pending?limit=10';
    const posts = await apiFetch(query);
    if (!Array.isArray(posts)) return [];
    const results = [];
    for (const post of posts as PublishedFacebookPost[]) {
      const result = await checkSinglePostEngagement(post, true);
      const updated = Boolean(await apiFetch(`/api/jobs/${post.id}/engagement`, result));
      results.push({ postId: post.id, result, updated });
      console.log('[PostAnalytics] Engagement sync completed', { postId: post.id, result, updated });
    }
    return results;
  } finally {
    isEngagementBatchRunning = false;
    isFacebookSyncBusy = false;
  }
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message.type === 'TRIGGER_SINGLE_ENGAGEMENT_SYNC' && message.post) {
    void checkSinglePostEngagement(message.post as PublishedFacebookPost)
      .then(async (result) => {
        const updated = Boolean(await apiFetch(`/api/jobs/${message.post.id}/engagement`, result));
        sendResponse({ ok: true, result, updated, postId: message.post.id });
      })
      .catch((err) => sendResponse({ ok: false, error: err?.message ?? 'Engagement sync failed' }));
    return true;
  }
  if (message.type !== 'TRIGGER_ENGAGEMENT_SYNC') return;
  void syncPublishedEngagementBatch(typeof message.postId === 'string' ? message.postId : undefined)
    .then((results) => sendResponse({ ok: true, results }))
    .catch((err) => sendResponse({ ok: false, error: err?.message ?? 'Engagement sync failed' }));
  return true;
});

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message.type !== 'TRIGGER_PENDING_POST_SYNC') return;
  void syncPendingPostsBatch()
    .then((results) => sendResponse({ ok: true, results }))
    .catch((err) => sendResponse({ ok: false, error: err?.message ?? 'Pending post batch failed' }));
  return true;
});

// ── Alarms ──

chrome.alarms.create(HEARTBEAT_ALARM, {
  periodInMinutes: HEARTBEAT_INTERVAL_MINUTES,
});
chrome.alarms.create(PENDING_POST_SYNC_ALARM, {
  periodInMinutes: PENDING_POST_SYNC_INTERVAL_MINUTES,
});
// Engagement checks are explicitly user-triggered from the dashboard. An
// automatic alarm can open a previously stored post URL while a new post is
// being published, so do not schedule background navigation for analytics.
void chrome.alarms.clear(ENGAGEMENT_SYNC_ALARM);

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === REGISTER_RETRY_ALARM) {
    void registerExtension();
  }
  if (alarm.name === HEARTBEAT_ALARM) {
    sendHeartbeat();
    void refreshFacebookSession();
    checkPendingJobs(); // Also check jobs on heartbeat
  }
  if (alarm.name === PENDING_POST_SYNC_ALARM) {
    void syncPendingPostsBatch();
  }
});

// ── Startup ──

void registerExtension();

chrome.runtime.onStartup.addListener(() => {
  registerExtension();
  sendHeartbeat();
  checkPendingJobs();
});

chrome.runtime.onInstalled.addListener(() => {
  registerExtension();
  sendHeartbeat();
  checkPendingJobs();
});
